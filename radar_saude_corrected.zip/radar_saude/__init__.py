"""Mark the top-level radar_saude directory as a Python package."""
